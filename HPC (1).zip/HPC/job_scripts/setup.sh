#!/bin/bash

module load gcc/12.2.0

echo "GCC version:"
gcc --version | head -1
echo

BEST_GPU=$(nvidia-smi --query-gpu=index,utilization.gpu,memory.used \
  --format=csv,noheader,nounits | \
  awk -F',' '{gsub(/ /,"",$0); print $1","$2","$3}' | \
  sort -t',' -k2,2n -k3,3n | \
  head -n 1 | \
  cut -d',' -f1)

export CUDA_VISIBLE_DEVICES=$BEST_GPU

echo "Selected least-busy GPU: $BEST_GPU"
nvidia-smi --query-gpu=index,name,utilization.gpu,memory.used --format=csv | grep "^$BEST_GPU,"

cd ~/Desktop/HPC

echo
echo "Current directory:"
pwd